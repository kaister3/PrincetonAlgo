import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] grid;
    private final int length; // the length of the grid
    private int count;
    private final static int top = 0; // virtual top
    private final int bottom; // virtual bottom
    private WeightedQuickUnionUF uf; // the instance
    private WeightedQuickUnionUF uf2;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();
        length = n;
        grid = new boolean[n][n];
        count = 0;
        bottom = n * n + 1;
        uf = new WeightedQuickUnionUF(n * n + 2);
        uf2 = new WeightedQuickUnionUF(n * n + 1);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = false;
          }
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        grid[row - 1][col - 1] = true;
        count++;
        if (row == 1) {
            uf.union(getIndex(row, col), top);
            uf2.union(getIndex(row, col), top);
        }
        if (row == length) {
            uf.union(getIndex(row, col), bottom);
        }
        if (row > 1 && isOpen(row - 1, col)) {
            uf.union(getIndex(row, col), getIndex(row - 1, col));
            uf2.union(getIndex(row, col), getIndex(row - 1, col));
        }
        if (row < length && isOpen(row + 1, col)) {
            uf.union(getIndex(row, col), getIndex(row + 1, col));
            uf2.union(getIndex(row, col), getIndex(row + 1, col));
        }
        if (col > 1 && isOpen(row, col - 1)) {
            uf.union(getIndex(row, col - 1), getIndex(row, col));
            uf2.union(getIndex(row, col - 1), getIndex(row, col));
        }
        if ((col < length) && isOpen(row, col + 1)) {
            uf.union(getIndex(row, col + 1), getIndex(row, col));
            uf2.union(getIndex(row, col + 1), getIndex(row, col));
        }
    }

    private int getIndex(int row, int col) {
        return (row - 1) * length + col;
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        return grid[row - 1][col - 1];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row <= 0 || row > length || col <= 0 || col > length) {
            throw new IllegalArgumentException();
        }
        return uf2.connected(getIndex(row, col), top);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return count;
    }

    // does the system percolate?
    public boolean percolates() {
        return uf.connected(top, bottom);
    }

    // test client (optional)
    public static void main(String[] args) {
        //
    }
}
