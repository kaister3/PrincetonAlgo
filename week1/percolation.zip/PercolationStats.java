import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private double[] fractions;
    private int numOfExperiments;
    private final static double confidence_95 = 1.96;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }

        numOfExperiments = trials;
        fractions = new double[trials];
        for (int indexOfExp = 0; indexOfExp < numOfExperiments; indexOfExp++) {
            Percolation pr = new Percolation(n);
            int openSite = 0;
            while (!pr.percolates()) {
                int row = StdRandom.uniform(n) + 1;
                int col = StdRandom.uniform(n) + 1;
                if (!pr.isOpen(row, col)) {
                    pr.open(row, col);
                    openSite++;
                }
            }
            double fraction = (double) openSite / n * n;
            fractions[indexOfExp] = fraction;
        }
    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(fractions);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(fractions);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return StdStats.mean(fractions) - confidence_95 * stddev() / Math.sqrt(numOfExperiments);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return StdStats.mean(fractions) + confidence_95 * stddev() / Math.sqrt(numOfExperiments);
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        /* PercolationStats prs = new PercolationStats(n, t);
        String confidence = "[" + prs.confidenceLo() + ", "
                + prs.confidenceHi() + "]";
        StdOut.println("mean                    = " + prs.mean());
        StdOut.println("stddev                  = " + prs.stddev());
        StdOut.println("95% confidence interval = " + confidence);*/
    }

}